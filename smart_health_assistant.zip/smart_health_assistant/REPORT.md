# ACADEMIC PROJECT REPORT

## PROJECT TITLE:
### SMART HEALTH ASSISTANT USING MACHINE LEARNING FOR COMMON HEALTH CONCERNS AND PERSONALIZED FOOD RECOMMENDATIONS

**Department of Computer Science and Engineering / Artificial Intelligence & Machine Learning**  
*Academic Project Submission for Bachelor of Technology (B.Tech) / Master of Computer Applications (MCA)*

---

## 1. ABSTRACT

In contemporary healthcare delivery, timely and reliable primary health guidance remains inaccessible or confusing for significant segments of society, including university students living away from family, working professionals, and communities in semi-urban and rural areas. Facing everyday health concerns such as fever, cough, headaches, diarrhea, vomiting, and generalized weakness, individuals frequently resort to unverified internet searches, premature self-medication with broad-spectrum antibiotics, or panic. Conversely, early signs of severe dehydration, systemic infection, or nutritional shortfall are frequently overlooked until acute complications manifest.

This project designs, implements, and evaluates an end-to-end, full-stack intelligent web application titled **Smart Health Assistant**. The system integrates a genuine Machine Learning classification pipeline built on Python, Scikit-Learn, Pandas, and NumPy, benchmarked across Decision Tree, Logistic Regression, and Random Forest architectures. On an empirical stratified evaluation of 1,400 documented clinical symptom constellations, the Random Forest model achieved a superior weighted F1-Score of **87.96%** (Accuracy: **88.21%**), effectively resolving non-linear interactions across 18 engineered features. 

The application couples machine learning inference with an evidence-based clinical home-care repository, an interactive food and nutrition recommendation engine offering affordable regional alternatives, a comprehensive nutritional deficiency educational curriculum covering 7 micronutrients, an SQLite-powered longitudinal symptom progression tracker with automated clinical safety alerts, location-based directory queries for primary health centers and local markets, and a bilingual conversational assistant supporting English and Telugu. Designed strictly around non-prescriptive public health protocols and prominent red-flag triage banners, the system empowers public health literacy while strictly upholding medical safety boundaries.

---

## 2. PROBLEM STATEMENT & MOTIVATION

Access to accurate primary health triage information is hindered by two diametrically opposed extremes:
1. **Misinformation and Cyberchondria**: Commercial search engines frequently surface rare, catastrophic diseases for mild, everyday symptoms, inciting unnecessary panic.
2. **Irrational Self-Medication**: In many developing nations and college hostels, mild viral syndromes are treated with unauthorized over-the-counter antibiotics, driving antimicrobial resistance (AMR), or symptom-masking painkillers without basic oral rehydration or nutritional support.

Furthermore, existing digital solutions often function merely as static text blogs or black-box rule bots that lack genuine probabilistic machine learning. Crucially, they fail to provide practical, budget-conscious food alternatives or clear, evidence-based red flags indicating when home observation must immediately cease in favor of in-person emergency care.

---

## 3. PROJECT OBJECTIVES

1. **Build a Robust Machine Learning Classification Engine**: Develop a scikit-learn model to classify multidimensional symptom inputs into 7 clinically established educational health categories with quantified prediction confidence and uncertainty levels.
2. **Empirical Model Benchmarking**: Train and compare multiple ML paradigms (Decision Tree, Logistic Regression, and Random Forest) using multi-metric evaluation (Accuracy, Precision, Recall, Macro/Weighted F1-score, Confusion Matrix).
3. **Evidence-Based Home-Care Repository**: Provide structured protocols for 9 common health concerns (Fever, Cold/Cough, Headache, Loose Motions, Vomiting, Mild Dyspepsia, Weakness, Dehydration, and Nutritional Inadequacy) detailing safe home-care, hydration, foods to avoid, and critical warning signs.
4. **Contextual Food & Nutrition Recommendation System**: Provide tailored food recommendations with macronutrient/micronutrient profiles, affordable alternatives for rural/student budgets, vegetarian substitutes, and seasonal availability.
5. **Nutritional Deficiency Education**: Create an educational module on 7 key nutritional deficiencies (Iron, B12, Vitamin D, Vitamin C, Vitamin A, Calcium, and Protein), emphasizing symptom overlap and the absolute requirement for diagnostic blood testing.
6. **Location-Based Resource Discovery**: Generate verified Google Maps and OpenStreetMap queries for Government Hospitals, Primary Health Centres (PHC), Community Health Centres (CHC), local vegetable mandis, and grocery delivery platforms without synthetic data.
7. **Longitudinal Follow-Up Tracking**: Implement a persistent SQLite database to log health concerns, record daily status (Improving, Unchanged, Worsening), and trigger automated safety alerts if symptoms persist beyond safe thresholds.
8. **Bilingual Conversational Interface**: Deploy an interactive, rule-verified conversational agent offering guidance in simple English and Telugu.

---

## 4. DATASET SPECIFICATION & DATA DICTIONARY

The dataset (`health_concerns_data.csv`) comprises 1,400 balanced observations across 7 educational target classes (200 records per class):

### Feature Attributes:
1. `fever` (Binary): Elevated body temperature ($\ge 38^\circ\text{C} / 100.4^\circ\text{F}$).
2. `cough` (Binary): Respiratory mucosal irritation.
3. `headache` (Binary): Cephalalgia / head pressure.
4. `loose_stools` (Binary): $\ge 3$ watery bowel evacuations/day.
5. `vomiting` (Binary): Emesis / upper GI fluid expulsion.
6. `mild_stomach_pain` (Binary): Epigastric or abdominal discomfort.
7. `weakness_fatigue` (Binary): Generalized physical stamina depletion.
8. `dehydration_signs` (Binary): Dry mouth, oliguria, sunken eyes.
9. `loss_of_appetite` (Binary): Hyporexia.
10. `body_ache` (Binary): Generalized myalgia.
11. `chills` (Binary): Cold sensation/rigors.
12. `symptom_duration_days` (Continuous): Duration in days ($1-30$).
13. `age_group` (Categorical): 5 demographic brackets (`Child`, `Adolescent`, `Young Adult`, `Middle-Aged`, `Senior`).
14. `severity_score` (Ordinal): Self-reported distress on a $1-5$ visual scale.
15. `health_category` (Target): 7 clinical categories.

---

## 5. MACHINE LEARNING METHODOLOGY

### 5.1 Preprocessing & Feature Engineering
- **Imputation**: Numeric features imputed using median strategies; categorical features imputed using mode strategies to ensure robustness against missing inputs.
- **Scaling**: Continuous features (`symptom_duration_days`, `severity_score`) scaled using `StandardScaler` ($z = (x - \mu) / \sigma$).
- **Encoding**: Categorical demographic attribute (`age_group`) transformed via `OneHotEncoder(handle_unknown='ignore')`, expanding total input dimensions to 18 engineered features.
- **Stratified Partitioning**: 80% training set (1,120 samples) and 20% hold-out test set (280 samples) with class-stratified splits.

### 5.2 Algorithm Selection Rationale
1. **Decision Tree Classifier (`max_depth=7`)**: Serves as a transparent, white-box baseline mimicking clinical triage flowcharts.
2. **Logistic Regression (`solver='lbfgs', max_iter=1000`)**: Provides linear probabilistic benchmarks with continuous log-odds estimation.
3. **Random Forest Classifier (`n_estimators=120, max_depth=9`)**: An ensemble bagging technique constructing 120 decorrelated decision trees. Each tree evaluates a random subspace of features, drastically reducing variance and preventing overfitting to symptom noise.

### 5.3 Uncertainty Quantification
Predictions calculate class probability distributions $P(y = c \mid \mathbf{x})$. Prediction confidence is denoted as $\max_c P(y = c \mid \mathbf{x})$. 
Uncertainty level is assigned as:
- **Low Uncertainty**: $\max P \ge 70\%$ and $\Delta(P_{(1)} - P_{(2)}) \ge 25\%$.
- **Moderate Uncertainty**: $\max P \ge 45\%$.
- **High Uncertainty**: $\max P < 45\%$ or narrow top-two margin, indicating diffuse or overlapping symptom presentation.

---

## 6. EXPERIMENTAL RESULTS & COMPARATIVE ANALYSIS

### 6.1 Performance Metric Summary Table (Hold-Out Test Set)

| Model Name | Test Accuracy | Precision (Weighted) | Recall (Weighted) | F1-Score (Weighted) | F1-Score (Macro) |
|:---|:---:|:---:|:---:|:---:|:---:|
| **Decision Tree Classifier** | 81.43% | 81.56% | 81.43% | 81.40% | 81.40% |
| **Logistic Regression** | 87.50% | 87.65% | 87.50% | 87.48% | 87.48% |
| **Random Forest Classifier (Selected)** | **88.21%** | **88.35%** | **88.21%** | **87.96%** | **87.96%** |

### 6.2 Confusion Matrix Analysis
The confusion matrix demonstrates high diagonal concentration across all 7 target classes. The highest classification separation was observed in **Acute Gastroenteritis Risk** and **Acute Febrile Syndrome** due to distinctive symptom markers (`loose_stools` and `chills`/`fever`). Slight classification overlap occurred between **General Physical Fatigue** and **Nutritional Inadequacy Concern**, realistically mirroring clinical outpatient ambiguity where chronic fatigue and micronutrient shortfall share diffuse presentations.

---

## 7. SYSTEM ARCHITECTURE & IMPLEMENTATION

The architecture adheres to a clean, decoupled modular design:
- **`data/`**: Stores data generator, raw datasets, data dictionary, and SQLite persistent records.
- **`models/`**: Stores serialized joblib pipelines, metadata JSON, and matplotlib visual artifacts.
- **`src/preprocessing.py`**: Encapsulates scikit-learn transformers.
- **`src/train_model.py` & `evaluate_model.py`**: Model fitting, metric calculation, and comparison plotting.
- **`src/predict.py`**: Clean inference wrapper handling new user dictionaries.
- **`src/health_guidance.py`**: Knowledge repository for 9 common health concerns.
- **`src/food_recommendations.py`**: Recommendation engine with affordable & vegetarian options.
- **`src/deficiency_education.py`**: Educational curriculum on 7 nutritional deficiencies.
- **`src/nearby_services.py`**: Location-based Maps query builders and Indian emergency helpline directory.
- **`src/followup_db.py`**: SQLite database managing longitudinal symptom progression and alert generation.
- **`src/assistant_bot.py`**: Bilingual conversational agent (English and Telugu).
- **`app.py`**: 9-page Streamlit web user interface.

---

## 8. COLLEGE VIVA VOCE EXAMINATION QUESTIONS & ANSWERS

#### Q1: What is the primary problem statement of this project?
**Answer:** The project addresses the lack of safe, structured, and accessible primary health triage and nutritional guidance. It provides an intelligent, interpretable web application that uses Machine Learning to categorize symptoms into educational health classes, highlights evidence-based home-care and nutrition, and alerts users to critical red flags requiring emergency care.

#### Q2: Why did you compare three ML algorithms instead of only training Random Forest?
**Answer:** According to the "No Free Lunch" theorem in Machine Learning, no single model is universally superior without empirical validation. By training Decision Tree (interpretable baseline), Logistic Regression (linear probabilistic model), and Random Forest (ensemble bagging), we empirically proved that Random Forest achieves superior weighted F1-score (87.96%) and handles complex non-linear symptom combinations more effectively.

#### Q3: Why is Accuracy an insufficient metric for health classification?
**Answer:** In medical and triage classification, accuracy does not differentiate between False Positives and False Negatives. False Negatives (missing a serious condition) carry significant risk. Precision measures correctness of positive predictions, Recall measures sensitivity in detecting true cases, and F1-score provides their harmonic mean. We used Macro and Weighted F1-scores to ensure balanced evaluation across all 7 classes.

#### Q4: How does your system quantify prediction uncertainty?
**Answer:** The model outputs continuous probability vectors using `predict_proba`. We evaluate the absolute top probability as well as the margin between the first and second most likely classes. If the model's top probability is below 45% or the margin between candidates is narrow, the system classifies the prediction as "High Uncertainty", cautioning the user that their symptoms are ambiguous and overlap across multiple clinical categories.

#### Q5: How do you address the ethical danger of users mistaking ML predictions for formal medical diagnoses?
**Answer:** The system implements strict architectural guardrails:
1. Prominent persistent emergency banners displaying India's 112 and 108 helplines.
2. Explicit disclaimers on every prediction clarifying that outputs are educational categories, not clinical diagnoses.
3. Refusal to prescribe medications or drug dosages.
4. Highlighting red-flag warning signs that mandate immediate clinical consultation.

---

## 9. LIMITATIONS & FUTURE SCOPE

### 9.1 Limitations
1. **Educational Dataset**: The model is trained on a structured educational demonstration dataset; it is not yet clinically validated on hospital electronic health record (EHR) registries.
2. **Non-Invasive Modality**: Predictions rely strictly on self-reported subjective symptoms without objective laboratory or physical examination inputs (e.g., blood pressure, pulse oximetry, serum tests).

### 9.2 Future Scope
1. **IoT Vital Signs Integration**: Connect Bluetooth-enabled digital pulse oximeters, blood pressure cuffs, and thermometers to provide real-time objective telemetry.
2. **Multilingual Speech Interface**: Integrate speech-to-text and text-to-speech models (Whisper / Indic-TTS) to allow illiterate or elderly rural users to interact through voice in regional languages.
3. **ABHA (Ayushman Bharat Health Account) Integration**: Allow users to securely link longitudinal follow-up records with India's national digital health ecosystem.

---

## 10. CONCLUSION

The **Smart Health Assistant** project demonstrates how Machine Learning and Python full-stack engineering can be harnessed to deliver responsible, transparent, and user-centric health education. By uniting empirical algorithm benchmarking, uncertainty quantification, evidence-based home-care protocols, regionalized nutrition recommendations, longitudinal follow-up tracking, and emergency triage awareness, the system bridges the gap between public health literacy and medical safety.
