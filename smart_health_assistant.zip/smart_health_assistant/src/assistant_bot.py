"""
Interactive Health Assistant (Rule & Clinical Knowledge Engine)
Provides controlled, safe conversational responses with bilingual (English & Telugu) support.
Covers home care, ORS guidance, dehydration checks, diet, red flags, and facility navigation.
"""

INTENT_KNOWLEDGE_BASE = [
    {
        "keywords": ["ors", "oral rehydration", "loose motion", "diarrhea", "diarrhoea", "watery stool"],
        "en": (
            "**Oral Rehydration Salts (ORS) & Diarrhea Care:**\n"
            "- **Preparation:** Dissolve 1 standard WHO-ORS sachet completely in 1 liter (1000 ml) of clean drinking water.\n"
            "- **Intake:** Sip 100-200 ml slowly after every loose bowel movement. Do not boil the water after mixing.\n"
            "- **Food:** Continue eating light foods like curd rice, boiled potatoes, ripe bananas, and khichdi.\n"
            "- **Warning Signs:** If you see blood in stools, vomit continuously, or cannot pass urine for 6 hours, seek immediate medical care at a hospital or PHC."
        ),
        "te": (
            "**ఓరల్ రీహైడ్రేషన్ సాల్ట్స్ (ORS) & విరేచనాల సంరక్షణ:**\n"
            "- **తయారీ విధానం:** ఒక పూర్తి WHO-ORS ప్యాకెట్‌ను 1 లీటరు శుభ్రమైన తాగునీటిలో కలపండి.\n"
            "- **తీసుకోవలసిన విధానం:** ప్రతి విరేచనం తర్వాత 100-200 మి.లీ నెమ్మదిగా తాగండి. కలిపిన నీటిని మరిగించవద్దు.\n"
            "- **ఆహారం:** పెరుగు అన్నం, ఉడికించిన బంగాళాదుంపలు, అరటిపండు, పెసరపప్పు కిచిడీ తీసుకోండి.\n"
            "- **ప్రమాద సంకేతాలు:** మలంలో రక్తం పడినా, ఆగకుండా వాంతులు అయినా, లేదా 6 గంటల పాటు మూత్రం రాకపోయినా వెంటనే వైద్యుడిని లేదా సమీప ఆసుపత్రిని సంప్రదించండి."
        )
    },
    {
        "keywords": ["fever", "temperature", "chills", "feverish", "high fever"],
        "en": (
            "**Safe Home Care for Fever:**\n"
            "- **Rest & Environment:** Take complete bed rest in a well-ventilated, comfortable room.\n"
            "- **Clothing:** Wear light, breathable cotton clothes. Do not bundle up in heavy blankets.\n"
            "- **Cooling:** Use a lukewarm water damp cloth sponge on the forehead and neck if uncomfortable.\n"
            "- **Nutrition & Hydration:** Sip warm vegetable soups, coconut water, and dal khichdi.\n"
            "- **Red Flags:** If fever exceeds 103°F (39.4°C), lasts over 3 days, or is accompanied by a stiff neck, confusion, or rash, see a doctor immediately."
        ),
        "te": (
            "**జ్వరం వచ్చినప్పుడు తీసుకోవలసిన సురక్షిత సంరక్షణ:**\n"
            "- **విశ్రాంతి:** గాలి వెలుతురు ఉండే గదిలో పూర్తి విశ్రాంతి తీసుకోండి.\n"
            "- **దుస్తులు:** తేలికపాటి కాటన్ దుస్తులు ధరించండి. మందపాటి దుప్పట్లు కప్పుకోవద్దు.\n"
            "- **స్పాంజింగ్:** గోరువెచ్చని నీటితో తడిపిన గుడ్డతో నుదిటిపై మెల్లగా అద్దండి.\n"
            "- **ఆహారం & ద్రవాలు:** కొబ్బరి నీళ్ళు, వేడి కూరగాయల సూప్, పెసరపప్పు కిచిడీ తీసుకోండి.\n"
            "- **హెచ్చరిక:** జ్వరం 103°F దాటినా, 3 రోజుల కంటే ఎక్కువ ఉన్నా, మెడ నొప్పి లేదా తలతిరగడం ఉంటే వెంటనే డాక్టర్‌ను సంప్రదించండి."
        )
    },
    {
        "keywords": ["vomit", "vomiting", "nausea", "feeling sick", "throwing up"],
        "en": (
            "**Safe Management for Nausea & Vomiting:**\n"
            "- **Stomach Rest:** Rest the stomach for 30-60 minutes immediately after vomiting.\n"
            "- **Hydration Technique:** Do not drink large glasses at once. Sip 1 teaspoon of ORS or water every 5 minutes.\n"
            "- **Food:** When vomiting subsides for 4-6 hours, reintroduce dry toast, plain rice kanji, or crackers.\n"
            "- **Red Flags:** Vomit containing dark blood ('coffee grounds'), severe sharp abdominal pain, or inability to hold fluids for 24 hours requires emergency clinical care."
        ),
        "te": (
            "**వాంతులు & వికారం సమయంలో సంరక్షణ:**\n"
            "- **విశ్రాంతి:** వాంతి అయిన వెంటనే 30-60 నిమిషాల వరకు ఏమీ తినవద్దు, కడుపుకి విశ్రాంతి ఇవ్వండి.\n"
            "- **ద్రవాలు:** ఒకేసారి ఎక్కువ నీరు తాగకూడదు. ప్రతి 5 నిమిషాలకు ఒక చెంచా ORS లేదా చల్లటి నీరు తాగండి.\n"
            "- **తేలికపాటి ఆహారం:** వాంతులు తగ్గాక డ్రై టోస్ట్, బియ్యం గంజి తీసుకోండి.\n"
            "- **హెచ్చరిక:** వాంతిలో రక్తం పడినా, తీవ్రమైన కడుపు నొప్పి ఉన్నా, లేదా 24 గంటలు ఏ ద్రవాలు ఆగకపోయినా వెంటనే ఆసుపత్రికి వెళ్ళండి."
        )
    },
    {
        "keywords": ["cough", "cold", "throat", "sore throat", "runny nose"],
        "en": (
            "**Cold and Cough Home Guidance:**\n"
            "- **Throat Relief:** Warm saline gargle (half tsp salt in warm water) 3 times daily.\n"
            "- **Inhalation:** Mild steam inhalation or warm moisture to loosen airway congestion.\n"
            "- **Fluids:** Warm ginger-tulsi herbal infusions or warm water with honey (for individuals over 1 year).\n"
            "- **Red Flags:** Shortness of breath, wheezing, coughing up blood, or cough persisting over 3 weeks requires medical evaluation."
        ),
        "te": (
            "**దగ్గు మరియు జలుబు జాగ్రత్తలు:**\n"
            "- **గొంతు ఉపశమనం:** గోరువెచ్చని ఉప్పు నీటితో రోజుకు 3 సార్లు పుక్కిలించండి (గార్గ్లింగ్).\n"
            "- **ఆవిరి:** ముక్కు దిబ్బడ తగ్గడానికి వేడి నీటి ఆవిరి పట్టండి.\n"
            "- **ద్రవాలు:** అల్లం-తులసి కషాయం లేదా గోరువెచ్చని నీటిలో తేనె కలుపుకుని తాగండి.\n"
            "- **హెచ్చరిక:** శ్వాస తీసుకోవడంలో ఇబ్బంది, దగ్గులో రక్తం రావడం లేదా 3 వారాల కంటే ఎక్కువ దగ్గు ఉంటే డాక్టర్‌ను సంప్రదించండి."
        )
    },
    {
        "keywords": ["headache", "head pain", "migraine", "temple pain"],
        "en": (
            "**Headache Home Care:**\n"
            "- **Hydration Check:** Drink 1-2 large glasses of water immediately; mild dehydration is a frequent trigger.\n"
            "- **Rest:** Rest in a dark, quiet, well-ventilated room with eyes shut.\n"
            "- **Compress:** Place a cool damp cloth over the forehead or a warm pad behind the neck.\n"
            "- **Red Flags:** Sudden explosive 'thunderclap' headache, stiff neck with fever, or weakness on one side of face/body requires calling 112/108 immediately."
        ),
        "te": (
            "**తలనొప్పి జాగ్రత్తలు:**\n"
            "- **నీరు తాగండి:** వెంటనే 1-2 గ్లాసుల మంచినీరు తాగండి; డీహైడ్రేషన్ వల్ల తలనొప్పి తరచుగా వస్తుంది.\n"
            "- **విశ్రాంతి:** నిశ్శబ్దంగా, చీకటిగా ఉన్న గదిలో కళ్ళు మూసుకుని విశ్రాంతి తీసుకోండి.\n"
            "- **కంప్రెస్:** నుదిటిపై చల్లటి గుడ్డను లేదా మెడ వెనుక గోరువెచ్చని గుడ్డను ఉంచండి.\n"
            "- **హెచ్చరిక:** ఆకస్మికంగా తీవ్రమైన తలనొప్పి రావడం, మెడ బిగుతుగా ఉండటం, లేదా శరీర భాగాల్లో బలహీనత ఉంటే వెంటనే 112/108 కు కాల్ చేయండి."
        )
    },
    {
        "keywords": ["weakness", "tired", "fatigue", "exhaustion", "low energy"],
        "en": (
            "**Weakness and Low Energy Tips:**\n"
            "- **Nutrition:** Consume balanced meals rich in iron and protein: sprouted moong, lentils, ragi, eggs, and moringa leaves.\n"
            "- **Sleep & Hydration:** Ensure 7-9 hours of consistent sleep and drink 2-3 liters of clean water daily.\n"
            "- **Medical Evaluation:** If fatigue persists beyond 2-3 weeks, see a physician for blood tests (CBC, Ferritin, Thyroid, B12, Vitamin D) rather than guessing deficiencies."
        ),
        "te": (
            "**నీరసం మరియు అలసట జాగ్రత్తలు:**\n"
            "- **పోషకాహారం:** ఐరన్ మరియు ప్రొటీన్ ఎక్కువగా ఉండే ఆహారం తీసుకోండి: మొలకెత్తిన పెసలు, పప్పులు, రాగి జావ, గుడ్లు, మునగాకు.\n"
            "- **నిద్ర & నీరు:** రోజుకు 7-9 గంటల నిద్ర మరియు 2-3 లీటర్ల శుభ్రమైన నీరు తాగండి.\n"
            "- **వైద్య పరీక్షలు:** 2-3 వారాల కంటే ఎక్కువ నీరసం కొనసాగితే రక్త పరీక్షల (CBC, B12, విటమిన్ D, థైరాయిడ్) కోసం డాక్టర్‌ను సంప్రదించండి."
        )
    },
    {
        "keywords": ["emergency", "ambulance", "hospital", "helpline", "doctor", "phone", "contact"],
        "en": (
            "**Emergency & Medical Helplines in India:**\n"
            "- **112:** All-in-One National Emergency Helpline (Ambulance, Police, Fire)\n"
            "- **108:** Free Emergency Medical Ambulance Service\n"
            "- **102:** Maternal and Infant Ambulance Transport\n"
            "- **104:** State Medical Information & Telemedicine Helpline\n"
            "- **1075:** National Health Helpline (Govt of India)"
        ),
        "te": (
            "**భారతదేశంలో అత్యవసర వైద్య హెల్ప్‌లైన్లు:**\n"
            "- **112:** జాతీయ అత్యవసర సహాయ సంఖ్య (అంబులెన్స్, పోలీస్, ఫైర్)\n"
            "- **108:** అత్యవసర వైద్య అంబులెన్స్ సర్వీస్\n"
            "- **102:** గర్భిణీలు మరియు శిశువుల అంబులెన్స్ సేవలు\n"
            "- **104:** ఉచిత వైద్య సలహా మరియు టెలిమెడిసిన్ హెల్ప్‌లైన్\n"
            "- **1075:** జాతీయ ఆరోగ్య హెల్ప్‌లైన్ (భారత ప్రభుత్వం)"
        )
    }
]

def get_assistant_response(user_query: str, lang: str = "English"):
    """
    Matches user query to verified clinical knowledge base and returns controlled, safe advice.
    """
    q = user_query.lower()
    
    for item in INTENT_KNOWLEDGE_BASE:
        if any(kw in q for kw in item["keywords"]):
            return item["te"] if lang.startswith("Telugu") else item["en"]

    # Default fallback response
    if lang.startswith("Telugu"):
        return (
            "**స్మార్ట్ హెల్త్ అసిస్టెంట్:**\n\n"
            "నేను సాధారణ ఆరోగ్య సమస్యలు (జ్వరం, జలుబు, దగ్గు, విరేచనాలు, వాంతులు, తలనొప్పి, నీరసం), "
            "సురక్షితమైన ఇంటి సంరక్షణ, పోషకాహారం, ORS తయారీ మరియు అత్యవసర హెల్ప్‌లైన్లపై సలహాలు ఇవ్వగలను.\n\n"
            "- దయచేసి మీ లక్షణాన్ని లేదా ప్రశ్నను స్పష్టంగా తెలపండి (ఉదా: 'fever care', 'ors preparation', 'weakness diet', 'emergency number').\n"
            "- **గమనిక:** ఇది కేవలం అవగాహన కోసం మాత్రమే. వైద్య మందులను మేము ప్రిస్క్రయిబ్ చేయము."
        )
    else:
        return (
            "**Smart Health Assistant:**\n\n"
            "I can guide you on common health concerns (fever, cold/cough, diarrhea, vomiting, headaches, fatigue), "
            "safe home care, nutritional foods, ORS preparation, dehydration, and emergency helplines.\n\n"
            "- Please ask a specific question (e.g., *'How to prepare ORS?'*, *'Fever home care'*, *'What to eat for weakness?'*, or *'Emergency ambulance number'*).\n"
            "- **Safety Note:** This tool provides educational guidance only and never prescribes prescription medicines."
        )
