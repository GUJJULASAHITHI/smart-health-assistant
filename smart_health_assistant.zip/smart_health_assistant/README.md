# Smart Health Assistant Using Machine Learning for Common Health Concerns and Personalized Food Recommendations

[![Python](https://img.shields.io/badge/Python-3.11-blue.svg)](https://www.python.org/)
[![Framework](https://img.shields.io/badge/Streamlit-1.66-red.svg)](https://streamlit.io/)
[![Machine Learning](https://img.shields.io/badge/Scikit--Learn-1.9-orange.svg)](https://scikit-learn.org/)
[![Database](https://img.shields.io/badge/SQLite-Local-lightgrey.svg)](https://sqlite.org/)

---

## 1. Project Overview & Problem Statement

Millions of people—including college students living away from home, working professionals, families, and residents in rural or semi-urban areas—frequently experience common health symptoms such as fevers, acute coughs, headaches, stomach upsets, loose motions, and persistent fatigue. 

Often, people either panic unnecessarily, delay basic fluid and electrolyte management, or consume self-prescribed over-the-counter antibiotics. Conversely, critical warning signs of severe dehydration or acute infection may be overlooked until complications arise.

**Smart Health Assistant** is an end-to-end, full-stack Machine Learning application developed from scratch to solve this challenge. It provides:
1. **Genuine ML Classification**: Multi-class symptom-to-condition educational categorization using scikit-learn models (Random Forest, Decision Tree, Logistic Regression) with prediction probabilities and uncertainty metrics.
2. **Safe Home-Care Protocols**: Evidence-based, non-prescriptive home care for 9 common health concerns.
3. **Personalized Nutrition Engine**: Context-specific foods, affordable alternatives for budget-conscious families, vegetarian options, and seasonal availability.
4. **Nutritional Deficiency Education**: In-depth educational guide for 7 essential deficiencies (Iron, B12, Vitamin D, Vitamin C, Vitamin A, Calcium, Protein) explaining symptom overlap and why clinical blood tests are required.
5. **Nearby Services & Emergency Helplines**: Location-based direct Google Maps and OpenStreetMap queries for Government Hospitals, Primary Health Centres (PHC), Community Health Centres (CHC), local vegetable mandis, and verified delivery links (Blinkit, BigBasket, Zepto, Swiggy Instamart) with official Indian emergency numbers (112, 108, 104, 102).
6. **Follow-Up & Safety Reminders**: Persistent SQLite progression tracker (Improving, Unchanged, Worsening) with automated safety alerts.
7. **Bilingual Interactive Assistant**: Controlled, safe conversational guidance in English and Telugu.

> **Safety Notice**: This system is designed solely for public health education and preliminary triage awareness. It is strictly non-prescriptive and does NOT replace licensed professional medical evaluation.

---

## 2. Project Directory Structure

```text
smart_health_assistant/
│
├── data/
│   ├── generate_dataset.py        # Dataset generation script (1,400 balanced records)
│   ├── health_concerns_data.csv   # Documented CSV symptom dataset
│   ├── data_dictionary.md         # Clinical feature definitions & permissible values
│   └── health_followup.db         # Persistent SQLite database for follow-up logs
│
├── models/
│   ├── best_health_model.joblib   # Serialized Random Forest classifier
│   ├── scaler_encoder.joblib      # ColumnTransformer with StandardScaler & OneHotEncoder
│   ├── all_models.joblib          # Dictionary containing all 3 candidate models
│   ├── model_metadata.json        # Class names, engineered features & test metrics
│   ├── confusion_matrix.png       # Confusion matrix visualization on test set
│   └── model_comparison.png       # Comparative bar chart across ML metrics
│
├── src/
│   ├── __init__.py
│   ├── preprocessing.py           # Imputation, encoding, and train-test split logic
│   ├── train_model.py             # Model training, multi-algorithm comparison & selection
│   ├── evaluate_model.py          # Standalone evaluation & classification report generator
│   ├── predict.py                 # Inference engine with uncertainty and probability scoring
│   ├── health_guidance.py         # Home care, hydration, and red flags for 9 health concerns
│   ├── food_recommendations.py    # Multi-category nutritional recommendation engine
│   ├── deficiency_education.py    # Detailed clinical education on 7 nutrient deficiencies
│   ├── nearby_services.py         # Google Maps/OSM search links & Indian emergency helplines
│   ├── followup_db.py             # SQLite database operations & progression alerts
│   └── assistant_bot.py           # Controlled bilingual conversational agent (English & Telugu)
│
├── app.py                         # Complete 9-page interactive Streamlit web application
├── requirements.txt               # Pinned project dependencies
├── README.md                      # Complete setup and user guide
└── REPORT.md                      # Comprehensive academic project report & Viva Q&A
```

---

## 3. Installation & Setup Instructions

### Prerequisites
- Python 3.9, 3.10, or 3.11 installed on your computer.
- Git (optional, for version control).

### Step 1: Open Terminal / PowerShell and Navigate to Project Directory
```powershell
cd C:\Users\Lenovo\.gemini\antigravity\scratch\smart_health_assistant
```

### Step 2: (Optional but Recommended) Create and Activate Virtual Environment
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### Step 3: Install Required Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Generate Dataset & Train Models (If re-training)
```powershell
# 1. Generate the documented educational dataset
python data/generate_dataset.py

# 2. Train and benchmark the candidate Machine Learning models
python src/train_model.py

# 3. View the detailed evaluation report in terminal
python src/evaluate_model.py
```

### Step 5: Launch the Streamlit Web Application
```powershell
streamlit run app.py
```
After running this command, open your browser and navigate to:
`http://localhost:8501`

---

## 4. Machine Learning Model Benchmark Results

On our stratified 80/20 train-test evaluation (1,120 training samples, 280 unseen test samples):

| Model Name | Test Accuracy | Precision (Weighted) | Recall (Weighted) | F1-Score (Weighted) | F1-Score (Macro) |
|:---|:---:|:---:|:---:|:---:|:---:|
| **Decision Tree Classifier** | 81.43% | 81.56% | 81.43% | 81.40% | 81.40% |
| **Logistic Regression** | 87.50% | 87.65% | 87.50% | 87.48% | 87.48% |
| **Random Forest Classifier (Selected)** | **88.21%** | **88.35%** | **88.21%** | **87.96%** | **87.96%** |

### Why Random Forest Was Selected:
1. **Non-Linear Interactions**: Real-world triage involves subtle interactions between symptoms (e.g., fever with loose motions indicates gastroenteritis, whereas fever with cough points to respiratory syndrome). Random Forest captures high-order non-linear interactions without severe bias.
2. **Generalization Power**: Ensembling 120 decision trees decorrelates individual tree errors, preventing overfitting on training noise.
3. **Calibrated Probabilities**: Provides robust probability estimates used directly to compute prediction uncertainty.

---

## 5. Deployment Guide (Streamlit Community Cloud)

To deploy this project online for free on Streamlit Community Cloud:
1. Push your project to a GitHub repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of Smart Health Assistant"
   git remote add origin https://github.com/<your-username>/smart-health-assistant.git
   git push -u origin main
   ```
2. Go to [share.streamlit.io](https://share.streamlit.io/) and sign in with your GitHub account.
3. Click **"New app"**, select your repository, set the branch to `main`, and main file path to `app.py`.
4. Click **"Deploy!"**. Your application will be live with a public URL you can share with professors and recruiters!
