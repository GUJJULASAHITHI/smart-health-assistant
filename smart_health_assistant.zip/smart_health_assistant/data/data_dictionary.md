# Dataset Documentation & Data Dictionary

## 1. Dataset Overview
- **Name**: Educational Health Concerns & Symptom Dataset (`health_concerns_data.csv`)
- **Purpose**: Academic and educational demonstration of multi-class classification for common outpatient health concerns.
- **Total Records**: 1,400 observations (200 records per category across 7 balanced target classes).
- **Domain**: Preventive healthcare triage education, home-care guidance, and nutritional referral.

---

## 2. Feature Specifications

| Feature Name | Data Type | Permissible Values | Description & Clinical Rationale |
|:---|:---|:---|:---|
| `fever` | Binary (int) | `0` (No), `1` (Yes) | Elevated core temperature (>=37.8°C / 100°F). Hallmark of acute febrile and infectious syndromes. |
| `cough` | Binary (int) | `0` (No), `1` (Yes) | Upper/lower respiratory irritation, common in colds, seasonal allergies, or flu. |
| `headache` | Binary (int) | `0` (No), `1` (Yes) | Cephalalgia; hallmark of tension headaches, migraines, eye strain, dehydration, or febrile illness. |
| `loose_stools` | Binary (int) | `0` (No), `1` (Yes) | Watery bowel movements (>=3 times/day). Primary indicator of acute gastroenteritis. |
| `vomiting` | Binary (int) | `0` (No), `1` (Yes) | Emesis or inability to retain fluids. High risk for electrolyte imbalance. |
| `mild_stomach_pain` | Binary (int) | `0` (No), `1` (Yes) | Epigastric or abdominal discomfort, cramping, indigestion, or gastroenteritis. |
| `weakness_fatigue` | Binary (int) | `0` (No), `1` (Yes) | Generalized lethargy, reduced physical stamina, malaise. Present across multiple conditions. |
| `dehydration_signs` | Binary (int) | `0` (No), `1` (Yes) | Extreme thirst, dry mucous membranes, oliguria (infrequent dark urine), or sunken eyes. |
| `loss_of_appetite` | Binary (int) | `0` (No), `1` (Yes) | Anorexia/hyporexia; reduced desire to consume food, common in infection and indigestion. |
| `body_ache` | Binary (int) | `0` (No), `1` (Yes) | Generalized myalgia, muscle stiffness, joint aches. Common in viral fevers and fatigue. |
| `chills` | Binary (int) | `0` (No), `1` (Yes) | Shivering or cold sensation associated with rapid changes in body temperature setpoint. |
| `symptom_duration_days` | Numeric (float/int)| `1` to `30` | Duration of the symptoms in days. Critical triage discriminator (acute vs subacute vs chronic). |
| `age_group` | Categorical | `Child (2-12)`, `Adolescent (13-17)`, `Young Adult (18-35)`, `Middle-Aged (36-59)`, `Senior (60+)` | Demographic age bracket affecting physiological vulnerability and nutritional requirements. |
| `severity_score` | Numeric (int) | `1` (Mild), `2` (Moderate-Mild), `3` (Moderate), `4` (Moderate-Severe), `5` (Severe) | Self-reported visual analog scale (VAS) score of symptom distress. |

---

## 3. Target Variable (`health_category`)

The 7 educational classification categories are:

1. **`Acute Febrile Syndrome`**: Fever-predominant systemic response, chills, body ache, typical of acute self-limiting viral illness.
2. **`Upper Respiratory Illness`**: Cough, rhinitis, mild fever, throat discomfort, typical of common cold or seasonal viral respiratory infection.
3. **`Acute Gastroenteritis Risk`**: Diarrhea, loose motions, vomiting, risk of dehydration, requiring immediate ORS hydration.
4. **`Tension / Fatigue Headache`**: Head pressure, neck strain, eye fatigue, lack of sleep, or screen-related cephalalgia.
5. **`General Physical Fatigue`**: Overwork, stress, inadequate recovery, physical exhaustion without acute infection.
6. **`Mild Dyspepsia / Gastric Discomfort`**: Acid reflux, bloating, epigastric fullness, irregular meal-related indigestion.
7. **`Nutritional Inadequacy Concern`**: Subacute/chronic low stamina, brittle nails, dull hair, poor dietary diversity, requiring balanced nutrition and physician lab workup.

---

## 4. Ethical, Regulatory & Clinical Disclaimers
1. **Academic & Educational Use Only**: This dataset and the resulting models are designed solely for college engineering projects and public health education.
2. **Non-Diagnostic**: The model output is a statistical prediction of educational relevance and must NEVER be treated as a definitive clinical diagnosis.
3. **No Delay in Care**: Red-flag symptoms (chest pain, severe breathlessness, high unyielding fever, persistent vomiting, severe dehydration) require immediate in-person medical evaluation.
