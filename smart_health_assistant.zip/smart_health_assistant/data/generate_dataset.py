"""
Educational Health Dataset Generator
Generates a realistic, documented clinical symptom dataset for educational classification.
Dataset contains 1,400 samples across 7 health categories.
"""

import numpy as np
import pandas as pd
import os

np.random.seed(42)

CATEGORIES = [
    "Acute Febrile Syndrome",
    "Upper Respiratory Illness",
    "Acute Gastroenteritis Risk",
    "Tension / Fatigue Headache",
    "General Physical Fatigue",
    "Mild Dyspepsia / Gastric Discomfort",
    "Nutritional Inadequacy Concern"
]

AGE_GROUPS = [
    "Child (2-12)",
    "Adolescent (13-17)",
    "Young Adult (18-35)",
    "Middle-Aged (36-59)",
    "Senior (60+)"
]

def generate_sample(category):
    # Base symptom probabilities conditioned on clinical pattern
    probs = {
        "fever": 0.05,
        "cough": 0.05,
        "headache": 0.10,
        "loose_stools": 0.03,
        "vomiting": 0.03,
        "mild_stomach_pain": 0.05,
        "weakness_fatigue": 0.15,
        "dehydration_signs": 0.02,
        "loss_of_appetite": 0.10,
        "body_ache": 0.08,
        "chills": 0.05,
        "symptom_duration_days": 3,
        "severity_score": 2
    }

    if category == "Acute Febrile Syndrome":
        probs["fever"] = 0.95
        probs["chills"] = 0.80
        probs["body_ache"] = 0.75
        probs["headache"] = 0.65
        probs["weakness_fatigue"] = 0.85
        probs["loss_of_appetite"] = 0.70
        duration = np.random.choice([1, 2, 3, 4, 5], p=[0.2, 0.35, 0.25, 0.15, 0.05])
        severity = np.random.choice([2, 3, 4], p=[0.25, 0.50, 0.25])

    elif category == "Upper Respiratory Illness":
        probs["cough"] = 0.92
        probs["fever"] = 0.45
        probs["headache"] = 0.50
        probs["body_ache"] = 0.40
        probs["weakness_fatigue"] = 0.60
        probs["loss_of_appetite"] = 0.40
        duration = np.random.choice([2, 3, 4, 5, 7, 10], p=[0.15, 0.30, 0.25, 0.15, 0.10, 0.05])
        severity = np.random.choice([1, 2, 3], p=[0.30, 0.50, 0.20])

    elif category == "Acute Gastroenteritis Risk":
        probs["loose_stools"] = 0.92
        probs["vomiting"] = 0.68
        probs["mild_stomach_pain"] = 0.75
        probs["dehydration_signs"] = 0.60
        probs["weakness_fatigue"] = 0.80
        probs["loss_of_appetite"] = 0.75
        probs["fever"] = 0.30
        duration = np.random.choice([1, 2, 3, 4], p=[0.35, 0.40, 0.15, 0.10])
        severity = np.random.choice([2, 3, 4], p=[0.20, 0.55, 0.25])

    elif category == "Tension / Fatigue Headache":
        probs["headache"] = 0.95
        probs["weakness_fatigue"] = 0.60
        probs["body_ache"] = 0.30
        probs["loss_of_appetite"] = 0.25
        duration = np.random.choice([1, 2, 3, 5], p=[0.45, 0.30, 0.15, 0.10])
        severity = np.random.choice([2, 3, 4], p=[0.30, 0.50, 0.20])

    elif category == "General Physical Fatigue":
        probs["weakness_fatigue"] = 0.96
        probs["body_ache"] = 0.45
        probs["headache"] = 0.40
        probs["loss_of_appetite"] = 0.50
        duration = np.random.choice([3, 5, 7, 10, 14], p=[0.15, 0.30, 0.30, 0.15, 0.10])
        severity = np.random.choice([1, 2, 3], p=[0.35, 0.45, 0.20])

    elif category == "Mild Dyspepsia / Gastric Discomfort":
        probs["mild_stomach_pain"] = 0.90
        probs["loss_of_appetite"] = 0.65
        probs["vomiting"] = 0.25
        probs["weakness_fatigue"] = 0.35
        duration = np.random.choice([1, 2, 3, 5, 7], p=[0.30, 0.35, 0.20, 0.10, 0.05])
        severity = np.random.choice([1, 2, 3], p=[0.40, 0.45, 0.15])

    elif category == "Nutritional Inadequacy Concern":
        probs["weakness_fatigue"] = 0.88
        probs["loss_of_appetite"] = 0.55
        probs["headache"] = 0.35
        probs["body_ache"] = 0.30
        duration = np.random.choice([7, 10, 14, 21, 30], p=[0.25, 0.30, 0.25, 0.10, 0.10])
        severity = np.random.choice([1, 2, 3], p=[0.50, 0.35, 0.15])

    # Sample binary features
    sample = {
        "fever": int(np.random.rand() < probs["fever"]),
        "cough": int(np.random.rand() < probs["cough"]),
        "headache": int(np.random.rand() < probs["headache"]),
        "loose_stools": int(np.random.rand() < probs["loose_stools"]),
        "vomiting": int(np.random.rand() < probs["vomiting"]),
        "mild_stomach_pain": int(np.random.rand() < probs["mild_stomach_pain"]),
        "weakness_fatigue": int(np.random.rand() < probs["weakness_fatigue"]),
        "dehydration_signs": int(np.random.rand() < probs["dehydration_signs"]),
        "loss_of_appetite": int(np.random.rand() < probs["loss_of_appetite"]),
        "body_ache": int(np.random.rand() < probs["body_ache"]),
        "chills": int(np.random.rand() < probs["chills"]),
        "symptom_duration_days": int(duration),
        "age_group": np.random.choice(AGE_GROUPS, p=[0.12, 0.15, 0.40, 0.23, 0.10]),
        "severity_score": int(severity),
        "health_category": category
    }
    return sample

def build_dataset(samples_per_category=200):
    records = []
    for cat in CATEGORIES:
        for _ in range(samples_per_category):
            records.append(generate_sample(cat))

    df = pd.DataFrame(records)
    
    # Introduce small realistic missingness (~1.5%) in non-critical columns to validate preprocessing imputation
    mask_duration = np.random.rand(len(df)) < 0.015
    df.loc[mask_duration, "symptom_duration_days"] = np.nan

    mask_age = np.random.rand(len(df)) < 0.015
    df.loc[mask_age, "age_group"] = np.nan

    # Shuffle dataset
    df = df.sample(frac=1.0, random_state=42).reset_index(drop=True)
    return df

if __name__ == "__main__":
    out_dir = os.path.dirname(os.path.abspath(__file__))
    df = build_dataset(samples_per_category=200)
    csv_path = os.path.join(out_dir, "health_concerns_data.csv")
    df.to_csv(csv_path, index=False)
    print(f"Dataset generated successfully with {len(df)} rows and {df.shape[1]} columns at {csv_path}")
    print("Class distribution:\n", df['health_category'].value_counts())
